/**
 * PostPress AI admin enhancements
 * Live preview + AJAX handlers
 */
(function ($) {
  "use strict";

  console.info("PPA: admin.js loaded (enhanced live preview)");

  // Cache elements
  const $subject = $("#ppa-subject");
  const $genre = $("#ppa-genre");
  const $tone = $("#ppa-tone");
  const $prompt = $("#ppa-prompt");
  const $previewTitle = $("#ppa-preview-title");
  const $previewMeta = $("#ppa-preview-meta");
  const $previewBody = $("#ppa-preview-body");
  const $saveDraftBtn = $("#ppa-save-draft-btn");
  const $previewBtn = $("#ppa-preview-btn");

  // ----------------------------
  // Live update handlers
  // ----------------------------
  function updatePreviewLive() {
    const subj = $subject.val() || "Untitled";
    const tone = $tone.val() || "Friendly";
    const genre = $genre.val() || "How-to";
    $previewTitle.text(subj);
    $previewMeta
      .html(`<span class="tone">Tone: ${tone}</span> • <span class="genre">Genre ${genre}</span>`)
      .css({ transition: "color 0.3s ease" });
  }

  $subject.on("input", updatePreviewLive);
  $tone.on("change", updatePreviewLive);
  $genre.on("change", updatePreviewLive);

  // ----------------------------
  // AJAX: Preview button
  // ----------------------------
  $previewBtn.on("click", function () {
    const data = {
      action: "ppa_preview",
      _ajax_nonce: PPA_AJAX.nonce,
      title: $subject.val(),
      prompt: $prompt.val(),
    };
    $previewBtn.prop("disabled", true).text("Loading...");
    $.post(PPA_AJAX.ajax_url, data, function (resp) {
      $previewBtn.prop("disabled", false).text("Preview");
      if (resp && resp.ok && resp.html) {
        $previewBody.html(resp.html);
      } else if (resp && resp.html === undefined) {
        $previewBody.html("<p><em>No HTML returned from preview endpoint.</em></p>");
      } else {
        console.warn("PPA preview response", resp);
      }
    }).fail(function (xhr) {
      console.error("Preview AJAX error", xhr.responseText);
      $previewBtn.prop("disabled", false).text("Preview");
    });
  });

  // ----------------------------
  // AJAX: Save draft button
  // ----------------------------
  $saveDraftBtn.on("click", function () {
    const data = {
      action: "ppa_save_draft",
      _ajax_nonce: PPA_AJAX.nonce,
      title: $subject.val(),
      prompt: $prompt.val(),
    };
    $saveDraftBtn.prop("disabled", true).text("Saving...");
    $.post(PPA_AJAX.ajax_url, data, function (resp) {
      $saveDraftBtn.prop("disabled", false).text("Save Draft");
      if (resp && resp.ok) {
        $previewBody.prepend(`<p class="ppa-success">✅ Draft saved (ID ${resp.post_id}).</p>`);
      } else {
        $previewBody.prepend(`<p class="ppa-error">❌ ${resp.error || "Save failed"}.</p>`);
      }
    }).fail(function (xhr) {
      console.error("Save draft AJAX error", xhr.responseText);
      $saveDraftBtn.prop("disabled", false).text("Save Draft");
    });
  });

  // Initialize live preview on load
  updatePreviewLive();
})(jQuery);
